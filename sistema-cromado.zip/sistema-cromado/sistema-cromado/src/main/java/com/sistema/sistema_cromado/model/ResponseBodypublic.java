package com.sistema.sistema_cromado.model;

/**
 * ResponseBodypublic
 */
public @interface ResponseBodypublic {

}
