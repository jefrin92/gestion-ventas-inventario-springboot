package com.sistema.sistema_cromado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaCromadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaCromadoApplication.class, args);
	}

}
