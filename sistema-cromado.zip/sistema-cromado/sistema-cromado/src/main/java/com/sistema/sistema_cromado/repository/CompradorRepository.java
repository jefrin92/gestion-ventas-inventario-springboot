package com.sistema.sistema_cromado.repository;

import com.sistema.sistema_cromado.model.Comprador;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CompradorRepository extends JpaRepository<Comprador, Long> {
}