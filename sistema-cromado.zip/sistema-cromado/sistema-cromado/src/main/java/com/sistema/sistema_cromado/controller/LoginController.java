package com.sistema.sistema_cromado.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {

    @GetMapping({"/", "/login"})
    public String loginForm() {
        return "login";
    }

    @PostMapping("/login")
    public String autenticar(@RequestParam String username, @RequestParam String password) {
        if ("admin".equals(username) && "12345".equals(password)) {
            return "redirect:/dashboard";
        }
        return "redirect:/login?error=true";
    }
}