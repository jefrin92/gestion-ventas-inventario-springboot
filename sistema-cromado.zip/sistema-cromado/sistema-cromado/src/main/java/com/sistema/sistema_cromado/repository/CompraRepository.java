package com.sistema.sistema_cromado.repository;

import com.sistema.sistema_cromado.model.Compra;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CompraRepository extends JpaRepository<Compra, Long> {
}