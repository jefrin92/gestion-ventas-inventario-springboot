package com.sistema.sistema_cromado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaCromadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
