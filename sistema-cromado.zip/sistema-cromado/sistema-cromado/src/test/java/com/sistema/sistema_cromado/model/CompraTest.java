package com.sistema.sistema_cromado.model;

/**
 * Pruebas unitarias del modelo {@code Compra}.
 */
public class CompraTest {
}
